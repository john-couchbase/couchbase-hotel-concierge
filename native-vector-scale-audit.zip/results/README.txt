NATIVE COUCHBASE VECTOR AUDIT

Start with results.html, recall.png and summary.csv. Raw SDK query results, EXPLAIN plans, index statistics and failure evidence are included. All recall ground truth came from native VECTOR_DISTANCE queries.

Data: deterministic synthetic 384-dimensional vectors; isolated scale_lab_20261103 scope, v10k and v50k collections. Not a language relevance or production capacity benchmark.

The first runner completed 10k tests but timed out on the 50k primary-index exact baseline. prepare_covering_baseline.py created a covering exact index; vector_scale_resume_50k.py completed the native 50k suite. Follow-up scripts test selective scalar exact search and the SQ8 anomaly. The IVF1 diagnostic creation timed out at the management client while its server build continued; finish_ivf1_probe.py checked its final query result. Do not blindly rerun setup scripts against existing collection/index names.

Credentials are deliberately excluded. Code expects private local files under work/. Public Capella CA certificate is included for statistics reads. These are recorded audit scripts, not a credential-free one-click deployment.

Cluster pause verified in cleanup-status.json. Test data remains for reproduction; storage costs continue.
