from pathlib import Path
import json, subprocess
BASE='https://cloudapi.cloud.couchbase.com/v4/organizations/efae365c-5f2c-410d-88b5-2b08add39160/projects/4eb78bf5-7122-43a5-b46d-3daff706de44/clusters/c45aa50d-b765-421b-a76c-f29abcfee4fa'
def request(path='',method='GET',body=None):
 key=next(x.split('=',1)[1].strip().strip('\"\'') for x in Path('work/capella-model-api-key.txt').read_text().splitlines() if '=' in x and 'secret' in x.split('=',1)[0].lower())
 args=['curl','-sS','--connect-timeout','8','--max-time','30','--config','-','-X',method,'-w','\n%{http_code}',BASE+path]
 if body is not None: args+=['--data-binary',json.dumps(body)]
 p=subprocess.run(args,input='header = "Authorization: Bearer '+key+'"\nheader = "Content-Type: application/json"\n',capture_output=True,text=True,timeout=35)
 if p.returncode:return {'status':0,'error':p.stderr.strip()}
 data,status=p.stdout.rsplit('\n',1)
 try:data=json.loads(data)
 except ValueError:pass
 return {'status':int(status),'body':data}
if __name__=='__main__':
 print(json.dumps(request('/mcpServers')))
