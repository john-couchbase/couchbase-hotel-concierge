import json,base64,subprocess
from pathlib import Path
from datetime import datetime,timezone
p=json.loads(Path('work/native-scale-credential.json').read_text());auth=base64.b64encode((p['username']+':'+p['password']).encode()).decode();out={'time':datetime.now(timezone.utc).isoformat(),'indexes':{}}
for col in ['v10k','v50k']:
 for index in ['scale_sq4','scale_sq8','scale_exact_cover']:
  if index=='scale_exact_cover' and col=='v10k':continue
  url=f'https://svc-dqise-node-001.brmmczevgpvlydb.cloud.couchbase.com:19102/api/v1/stats/vector-learning.{p["scope"]}.{col}/{index}'
  r=subprocess.run(['curl','-sS','--cacert','work/cluster-ca.pem','--connect-timeout','4','--max-time','10','--config','-','-w','\n%{http_code}',url],input='header = "Authorization: Basic '+auth+'"\n',text=True,capture_output=True)
  body,status=r.stdout.rsplit('\n',1)
  if status=='200':out['indexes'][col+'/'+index]=json.loads(body)
Path('outputs/vector-scale/index-stats.json').write_text(json.dumps(out,indent=2))
for key,data in out['indexes'].items():
 d=next(iter(data.values()));print(key,{k:d.get(k) for k in ['items_count','disk_size','memory_used','resident_percent','num_docs_pending']})
