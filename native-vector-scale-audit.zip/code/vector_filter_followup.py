import json,time
from pathlib import Path
from datetime import timedelta
from couchbase.cluster import Cluster
from couchbase.auth import PasswordAuthenticator
from couchbase.options import ClusterOptions,QueryOptions
from couchbase.n1ql import QueryScanConsistency
p=json.loads(Path('work/native-scale-credential.json').read_text());c=Cluster.connect('couchbases://cb.brmmczevgpvlydb.cloud.couchbase.com',ClusterOptions(PasswordAuthenticator(p['username'],p['password'])));c.wait_until_ready(timedelta(seconds=15))
out=Path('outputs/vector-scale');scope=p['scope'];ks=f'`vector-learning`.`{scope}`.`v10k`';q=json.loads((out/'design.json').read_text())['queries'][0];results=[]
def run(name,stmt,params):
 t=time.perf_counter();r=c.query(stmt,QueryOptions(named_parameters=params,scan_consistency=QueryScanConsistency.REQUEST_PLUS,metrics=True,timeout=timedelta(seconds=90)));rows=list(r.rows());rec={'name':name,'statement':stmt,'client_ms':1000*(time.perf_counter()-t),'server_ms':1000*r.metadata().metrics().execution_time().total_seconds(),'rows':rows};results.append(rec);(out/'filter-followup.json').write_text(json.dumps(results,indent=2));print(name,'rows',len(rows),flush=True);return rows
try:
 doc=c.bucket('vector-learning').scope(scope).collection('v10k').get('v001000').content_as[dict]
 (out/'rare-record-validation.json').write_text(json.dumps({'id':'v001000','dimensions':len(doc['embedding']),'norm_squared':sum(v*v for v in doc['embedding']),'metadata':{k:v for k,v in doc.items() if k!='embedding'}},indent=2))
 for bits in [4,8]:
  run(f'self-sq{bits}',f'SELECT META(d).id AS id FROM {ks} d USE INDEX (scale_sq{bits} USING GSI) ORDER BY APPROX_VECTOR_DISTANCE(d.embedding,$q,"COSINE",64,true,100) LIMIT 1',{'q':doc['embedding']})
 for candidates in [100,1000,10000]:
  for rerank in [False,True]:
   run(f'rare-sq8-top{candidates}-rerank{rerank}',f'SELECT META(d).id AS id FROM {ks} d USE INDEX (scale_sq8 USING GSI) WHERE d.rare=true ORDER BY APPROX_VECTOR_DISTANCE(d.embedding,$q,"COSINE",64,{str(rerank).lower()},{candidates}) LIMIT 10',{'q':q})
 for bits in [4,8]:
  run(f'coverage-sq{bits}',f'SELECT META(d).id AS id FROM {ks} d USE INDEX (scale_sq{bits} USING GSI) ORDER BY APPROX_VECTOR_DISTANCE(d.embedding,$q,"COSINE",64,false,10000) LIMIT 10000',{'q':q})
finally:c.close()
