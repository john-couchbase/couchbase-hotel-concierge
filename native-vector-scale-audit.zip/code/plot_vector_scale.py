import json
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
root=Path('outputs/vector-scale');s=json.loads((root/'summary.json').read_text())
fig,axes=plt.subplots(2,3,figsize=(13,7),sharex=True,sharey=True)
for row,n in enumerate([10000,50000]):
 for col,f in enumerate(['all','country_pets_parking','rare']):
  ax=axes[row,col]
  for bits,color in [(4,'#2465c5'),(8,'#d47919')]:
   for rerank,style in [(False,'--'),(True,'-')]:
    rs=sorted([r for r in s if r['n']==n and r['filter']==f and r['bits']==bits and r['rerank']==rerank],key=lambda r:r['probes'])
    ax.plot([r['probes'] for r in rs],[100*r['mean_recall'] for r in rs],style,marker='o',color=color,label=f'SQ{bits}, rerank {"on" if rerank else "off"}')
  ax.set_xscale('log',base=2);ax.set_xticks([1,8,64],['1','8','64']);ax.set_ylim(-3,103);ax.grid(alpha=.2);ax.set_title(f'{n:,} vectors · '+{'all':'no filter','country_pets_parking':'country + pets + parking','rare':'rare filter (0.1%)'}[f])
  if col==0:ax.set_ylabel('Mean recall@10 (%)')
  if row==1:ax.set_xlabel('Probes (64 configured cells)')
handles,labels=axes[0,0].get_legend_handles_labels();fig.legend(handles,labels,loc='upper center',bbox_to_anchor=(.5,.92),ncol=4,frameon=False)
fig.suptitle('Native Couchbase: filter correctness does not guarantee high recall',fontsize=17,y=.99)
fig.text(.02,.015,'Synthetic 384-D data; native exact ground truth; 8 queries at 10k and 16 at 50k. Single-node smoke audit, not production capacity.',fontsize=9)
fig.tight_layout(rect=[0,.04,1,.87]);fig.savefig(root/'recall.png',dpi=170);plt.close(fig)
print('Saved recall.png')
