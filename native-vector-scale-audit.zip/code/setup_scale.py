import sys,json,time,secrets,os
from pathlib import Path
from native_management import request
for i in range(60):
 state=request().get('body',{}).get('currentState')
 if i%6==0:print('Cluster',state,flush=True)
 if state=='healthy':break
 time.sleep(10)
else:raise SystemExit('Startup deadline exceeded')
r=request('/buckets');assert r['status']==200,r
b=next(x for x in r['body']['data'] if x['name']=='vector-learning');print('Bucket',json.dumps(b),flush=True)
bid=b['id'];base='/buckets/'+bid+'/scopes';scope='scale_lab_20261103'
r=request(base,'POST',{'name':scope});assert r['status']==201,r
for name in ['v10k','v50k']:
 r=request(base+'/'+scope+'/collections','POST',{'name':name});assert r['status']==201,r
password='Aa9!'+secrets.token_urlsafe(28)
r=request('/users','POST',{'name':'native-scale-runner','password':password,'credentialType':'basic','access':[{'privileges':['data_reader','data_writer'],'resources':{'buckets':[{'name':'vector-learning','scopes':[{'name':scope,'collections':['v10k','v50k']}]}]}}]})
assert r['status']==201,r
p=Path('work/native-scale-credential.json');p.write_text(json.dumps({'username':'native-scale-runner','password':password,'id':r['body']['id'],'scope':scope}));p.chmod(0o600)
print('Isolated collections and scoped test credential ready',flush=True)
