import json,time
from pathlib import Path
from datetime import timedelta
from couchbase.cluster import Cluster
from couchbase.auth import PasswordAuthenticator
from couchbase.options import ClusterOptions,QueryOptions
from native_management import request
out=Path('outputs/vector-scale');p=json.loads(Path('work/native-scale-credential.json').read_text());scope=p['scope'];c=Cluster.connect('couchbases://cb.brmmczevgpvlydb.cloud.couchbase.com',ClusterOptions(PasswordAuthenticator(p['username'],p['password'])));c.wait_until_ready(timedelta(seconds=15))
qs=json.loads((out/'design.json').read_text())['queries'];original=json.loads((out/'queries.json').read_text());results=[];plans={}
def run(q,params):
 t=time.perf_counter();r=c.query(q,QueryOptions(named_parameters=params,metrics=True,timeout=timedelta(seconds=45)));rows=list(r.rows());return {'rows':rows,'client_ms':1000*(time.perf_counter()-t),'server_ms':1000*r.metadata().metrics().execution_time().total_seconds()}
try:
 for n,col,qn in [(10000,'v10k',8),(50000,'v50k',16)]:
  ks=f'`vector-learning`.`{scope}`.`{col}`'
  for fname,idx,keys,pred,params in [('rare','scale_rare','rare','d.rare=true',{}),('country_pets_parking','scale_country','country,pets,parking','d.country=$country AND d.pets=true AND d.parking=true',{'country':'C1'})]:
   r=request('/queryService/indexes','POST',{'definition':f'CREATE INDEX {idx} ON {ks}({keys}) WITH {{"num_replica":0}}'});assert r['status']==200,r
   for i in range(60):
    s=request(f'/queryService/indexBuildStatus/{idx}?bucket=vector-learning&scope={scope}&collection={col}')
    if s.get('body',{}).get('status')=='Ready':break
    time.sleep(2)
   else:raise RuntimeError('Scalar index not ready')
   count=run(f'SELECT RAW COUNT(*) FROM {ks} d USE INDEX ({idx} USING GSI) WHERE {pred}',params)['rows'][0]
   for qi in range(qn):
    args=dict(params,q=qs[qi]);query=f'SELECT META(d).id AS id FROM {ks} d USE INDEX ({idx} USING GSI) WHERE {pred} ORDER BY VECTOR_DISTANCE(d.embedding,$q,"COSINE") LIMIT 10'
    if qi==0:
     plan=run('EXPLAIN '+query,args)['rows'];assert idx in json.dumps(plan);plans[f'{n}-{fname}']=plan
    r=run(query,args);truth=next(x for x in original if x['kind']=='exact' and x['n']==n and x['query']==qi and x['filter']==fname);expected={x['id'] for x in truth['rows']};got={x['id'] for x in r['rows']};r.update(n=n,query=qi,filter=fname,eligible_count=count,recall=len(got&expected)/len(expected),status='passed' if got==expected else 'failed');results.append(r)
   print(n,fname,'eligible',count,flush=True)
   (out/'scalar-comparison.json').write_text(json.dumps(results,indent=2));(out/'scalar-plans.json').write_text(json.dumps(plans,indent=2))
finally:c.close()
