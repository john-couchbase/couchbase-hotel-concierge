import json,time
from pathlib import Path
from datetime import timedelta
from couchbase.cluster import Cluster
from couchbase.auth import PasswordAuthenticator
from couchbase.options import ClusterOptions,QueryOptions
from couchbase.n1ql import QueryScanConsistency
from native_management import request
out=Path('outputs/vector-scale');p=json.loads(Path('work/native-scale-credential.json').read_text());scope=p['scope'];ks=f'`vector-learning`.`{scope}`.`v10k`';c=Cluster.connect('couchbases://cb.brmmczevgpvlydb.cloud.couchbase.com',ClusterOptions(PasswordAuthenticator(p['username'],p['password'])));c.wait_until_ready(timedelta(seconds=15));q=json.loads((out/'design.json').read_text())['queries'][0];results=[]
def run(name,idx,probes,limit=10):
 stmt=f'SELECT META(d).id AS id FROM {ks} d USE INDEX ({idx} USING GSI) WHERE d.rare=true ORDER BY APPROX_VECTOR_DISTANCE(d.embedding,$q,"COSINE",{probes},true,10000) LIMIT {limit}'
 try:
  t=time.perf_counter();r=c.query(stmt,QueryOptions(named_parameters={'q':q},scan_consistency=QueryScanConsistency.REQUEST_PLUS,timeout=timedelta(seconds=30)));rows=list(r.rows());v={'case':name,'rows':rows,'client_ms':1000*(time.perf_counter()-t),'status':'completed'}
 except Exception as e:v={'case':name,'status':'error','error':str(e)[:1000]}
 results.append(v);(out/'training-followup.json').write_text(json.dumps(results,indent=2));print(name,v['status'],'rows',len(v.get('rows',[])),flush=True)
try:
 run('existing-SQ8-probes128','scale_sq8',128)
 opts={'dimension':384,'similarity':'COSINE','description':'IVF64,SQ8','num_replica':0,'persist_full_vector':True,'train_list':10000}
 r=request('/queryService/indexes','POST',{'definition':f'CREATE VECTOR INDEX scale_sq8_fulltrain ON {ks}(embedding VECTOR) INCLUDE(country,tenant,pets,parking,rare) WITH '+json.dumps(opts)});assert r['status']==200,r
 for i in range(100):
  state=request(f'/queryService/indexBuildStatus/scale_sq8_fulltrain?bucket=vector-learning&scope={scope}&collection=v10k')
  if state.get('body',{}).get('status')=='Ready':break
  time.sleep(3)
 else:raise RuntimeError('Training deadline')
 run('full-training-SQ8-probes64','scale_sq8_fulltrain',64)
 if len(results[-1].get('rows',[]))<10:
  opts['description']='IVF1,SQ8'
  r=request('/queryService/indexes','POST',{'definition':f'CREATE VECTOR INDEX scale_sq8_ivf1 ON {ks}(embedding VECTOR) INCLUDE(country,tenant,pets,parking,rare) WITH '+json.dumps(opts)});assert r['status']==200,r
  for i in range(100):
   state=request(f'/queryService/indexBuildStatus/scale_sq8_ivf1?bucket=vector-learning&scope={scope}&collection=v10k')
   if state.get('body',{}).get('status')=='Ready':break
   time.sleep(3)
  else:raise RuntimeError('IVF1 build deadline')
  run('one-cell-SQ8-probes1','scale_sq8_ivf1',1)
finally:c.close()
