"""Bounded native Capella vector audit. Synthetic data, real SDK/index/query execution."""
import json,time,random,sys,concurrent.futures
from pathlib import Path
from datetime import timedelta,datetime,timezone
import numpy as np
from couchbase.cluster import Cluster
from couchbase.auth import PasswordAuthenticator
from couchbase.options import ClusterOptions,QueryOptions
from native_management import request
OUT=Path('outputs/vector-scale');OUT.mkdir(exist_ok=True);deadline=time.monotonic()+2700
cred=json.loads(Path('work/native-scale-credential.json').read_text());scope=cred['scope']
c=Cluster.connect('couchbases://cb.brmmczevgpvlydb.cloud.couchbase.com',ClusterOptions(PasswordAuthenticator(cred['username'],cred['password'])));c.wait_until_ready(timedelta(seconds=20))
def guard():
 if time.monotonic()>deadline:raise RuntimeError('45-minute runtime cap reached')
def sql(statement,params=None):
 guard();t=time.perf_counter();r=c.query(statement,QueryOptions(named_parameters=params or {},metrics=True,timeout=timedelta(seconds=60)));rows=list(r.rows());m=r.metadata().metrics()
 return {'rows':rows,'client_ms':1000*(time.perf_counter()-t),'server_ms':1000*m.execution_time().total_seconds()}
def ddl(statement):
 r=request('/queryService/indexes','POST',{'definition':statement})
 if r['status']!=200:raise RuntimeError(str(r))
 return r
def save(name,v):OUT.joinpath(name).write_text(json.dumps(v,indent=2))
rng=np.random.default_rng(20261103);centers=rng.normal(size=(64,384)).astype(np.float32);centers/=np.linalg.norm(centers,axis=1)[:,None]
labels=rng.integers(0,64,50000);vectors=centers[labels]+rng.normal(0,.055,(50000,384)).astype(np.float32);vectors/=np.linalg.norm(vectors,axis=1)[:,None];vectors=np.round(vectors,6)
meta=[{'country':'C'+str(int(labels[i])%5),'tenant':'t'+str(i%10),'pets':i%3==0,'parking':i%4==0,'rare':i%1000==0} for i in range(50000)]
queries=[]
for j in range(16):
 q=centers[j*3%64]+rng.normal(0,.06,384);q=q/np.linalg.norm(q);queries.append(np.round(q,6).tolist())
save('design.json',{'seed':20261103,'dimensions':384,'sizes':[10000,50000],'distribution':'64 clustered normalized Gaussian centers, Gaussian noise .055, rounded 6 decimals','queries':queries,'index':'IVF64, COSINE, SQ4/SQ8, INCLUDE strict filter fields, persist_full_vector true','limits':'45 minutes, existing single node only, no model calls; not a production load or RAM-exhaustion test'})
filters=[('all','TRUE',{},lambda d:True),('country_pets_parking','d.country=$country AND d.pets=true AND d.parking=true',{'country':'C1'},lambda d:d['country']=='C1' and d['pets'] and d['parking']),('tenant','d.tenant=$tenant',{'tenant':'t7'},lambda d:d['tenant']=='t7'),('rare','d.rare=true',{},lambda d:d['rare']),('no_match','d.country=$country',{'country':'Atlantis'},lambda d:False)]
allresults=[];stages=[];plans={}
try:
 for n in [10000,50000]:
  guard();name='v10k' if n==10000 else 'v50k';ks=f'`vector-learning`.`{scope}`.`{name}`';coll=c.bucket('vector-learning').scope(scope).collection(name)
  stage={'n':n,'collection':name};stages.append(stage);t=time.perf_counter()
  def batch(start):
   docs={f'v{i:06d}':dict(meta[i],embedding=vectors[i].tolist()) for i in range(start,min(start+100,n))}
   r=coll.upsert_multi(docs)
   if not r.all_ok:raise RuntimeError('Batch write failed; no successful ingest claim')
  with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
   for _ in pool.map(batch,range(0,n,100)):guard()
  stage['ingest_seconds']=time.perf_counter()-t;save('stages.json',stages);print('Loaded',n,'in',round(stage['ingest_seconds'],2),'seconds',flush=True)
  ddl(f'CREATE PRIMARY INDEX scale_primary ON {ks} WITH {{"num_replica":0}}')
  count=sql(f'SELECT RAW COUNT(*) FROM {ks} USE INDEX (scale_primary USING GSI)')['rows'][0];assert count==n,(count,n)
  stage['verified_count']=count;stage['indexes']=[]
  for bits in [4,8]:
   idx=f'scale_sq{bits}';t=time.perf_counter();opts={'dimension':384,'similarity':'COSINE','description':f'IVF64,SQ{bits}','num_replica':0,'persist_full_vector':True,'defer_build':True}
   ddl(f'CREATE VECTOR INDEX {idx} ON {ks}(embedding VECTOR) INCLUDE(country,tenant,pets,parking,rare) WITH '+json.dumps(opts))
   ddl(f'BUILD INDEX ON {ks}({idx}) USING GSI')
   until=time.monotonic()+600
   while time.monotonic()<until:
    guard();state=request(f'/queryService/indexBuildStatus/{idx}?bucket=vector-learning&scope={scope}&collection={name}')
    if state.get('body',{}).get('status')=='Ready':break
    time.sleep(3)
   else:raise RuntimeError('Index build deadline: '+idx)
   stage['indexes'].append({'name':idx,'build_client_seconds':time.perf_counter()-t});save('stages.json',stages)
   print(n,idx,'Ready',flush=True)
  truths={};qcount=8 if n==10000 else 16
  for qi in range(qcount):
   for fname,predicate,params,check in filters:
    p=dict(params,q=queries[qi]);base=f'FROM {ks} d';exact=f'SELECT META(d).id AS id {base} USE INDEX (scale_primary USING GSI) WHERE {predicate} ORDER BY VECTOR_DISTANCE(d.embedding,$q,"COSINE") LIMIT 10'
    r=sql(exact,p);truths[(qi,fname)]={x['id'] for x in r['rows']};r.update(n=n,query=qi,filter=fname,kind='exact',status='passed');allresults.append(r)
  save('queries.json',allresults)
  tasks=[(qi,f,b,pr,rr) for qi in range(qcount) for f in filters for b in [4,8] for pr in [1,8,64] for rr in [False,True]];random.Random(n).shuffle(tasks)
  for num,(qi,f,bits,probes,rerank) in enumerate(tasks):
   fname,predicate,params,check=f;idx=f'scale_sq{bits}';p=dict(params,q=queries[qi]);dist=f'APPROX_VECTOR_DISTANCE(d.embedding,$q,"COSINE",{probes},{str(rerank).lower()},100)'
   query=f'SELECT META(d).id AS id,d.country,d.tenant,d.pets,d.parking,d.rare FROM {ks} d USE INDEX ({idx} USING GSI) WHERE {predicate} ORDER BY {dist} LIMIT 10'
   key=f'{n}-{fname}-{bits}-{probes}-{rerank}'
   if key not in plans:
    plan=sql('EXPLAIN '+query,p)['rows'];plans[key]=plan;save('plans.json',plans)
    if idx not in json.dumps(plan):raise RuntimeError('Requested Hyperscale index absent: '+key)
   try:
    r=sql(query,p);truth=truths[(qi,fname)];got={x['id'] for x in r['rows']};violations=[x['id'] for x in r['rows'] if not check(meta[int(x['id'][1:])])]
    r.update(n=n,query=qi,filter=fname,kind='approximate',bits=bits,probes=probes,rerank=rerank,recall=len(got&truth)/len(truth) if truth else None,expected_count=len(truth),violations=violations,status='passed' if not violations and (truth or not got) else 'failed')
   except Exception as e:r={'n':n,'query':qi,'filter':fname,'bits':bits,'probes':probes,'rerank':rerank,'kind':'approximate','status':'error','error':str(e)}
   allresults.append(r)
   if num%30==0:save('queries.json',allresults);print('Native cases',n,num+1,'/',len(tasks),flush=True)
  # Parameter-injection and contradictory filters must return zero, even with vector ordering.
  for label,predicate,p in [('injection','d.country=$country',{'country':"C1\' OR TRUE --"}),('contradictory','d.country=$a AND d.country=$b',{'a':'C1','b':'C2'})]:
   p['q']=queries[0];q=f'SELECT META(d).id AS id FROM {ks} d USE INDEX (scale_sq8 USING GSI) WHERE {predicate} ORDER BY APPROX_VECTOR_DISTANCE(d.embedding,$q,"COSINE",64,true,100) LIMIT 10';r=sql(q,p);r.update(n=n,kind='negative_filter',filter=label,status='passed' if not r['rows'] else 'failed');allresults.append(r)
  save('queries.json',allresults);print('Completed size',n,flush=True)
finally:
 save('queries.json',allresults);save('stages.json',stages);c.close()
