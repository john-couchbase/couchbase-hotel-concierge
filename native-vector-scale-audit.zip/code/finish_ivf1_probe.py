from pathlib import Path
import json,time
exec(Path('work/vector_training_followup.py').read_text().split('try:\n run(')[0])
results=json.loads((out/'training-followup.json').read_text())
try:
 for i in range(24):
  state=request(f'/queryService/indexBuildStatus/scale_sq8_ivf1?bucket=vector-learning&scope={scope}&collection=v10k')
  if i%6==0:print('Diagnostic index',state.get('body'),flush=True)
  if state.get('body',{}).get('status')=='Ready':
   run('one-cell-SQ8-probes1','scale_sq8_ivf1',1);break
  time.sleep(5)
 else:
  results.append({'case':'one-cell-SQ8','status':'build_not_ready_within_followup_deadline','last_state':state});(out/'training-followup.json').write_text(json.dumps(results,indent=2))
finally:c.close()
