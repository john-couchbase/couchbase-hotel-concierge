import json,time
from pathlib import Path
from datetime import timedelta
from native_management import request
from couchbase.cluster import Cluster
from couchbase.auth import PasswordAuthenticator
from couchbase.options import ClusterOptions,QueryOptions
scope='scale_lab_20261103';ks=f'`vector-learning`.`{scope}`.`v50k`';r=request('/queryService/indexes','POST',{'definition':f'CREATE INDEX scale_exact_cover ON {ks}(country,tenant,pets,parking,rare,embedding) WITH {{"num_replica":0}}'});print('Create covering baseline',r,flush=True)
assert r['status']==200,r
for i in range(120):
 r=request(f'/queryService/indexBuildStatus/scale_exact_cover?bucket=vector-learning&scope={scope}&collection=v50k')
 if r.get('body',{}).get('status')=='Ready':break
 time.sleep(3)
else:raise SystemExit('Index build timeout')
p=json.loads(Path('work/native-scale-credential.json').read_text());c=Cluster.connect('couchbases://cb.brmmczevgpvlydb.cloud.couchbase.com',ClusterOptions(PasswordAuthenticator(p['username'],p['password'])));c.wait_until_ready(timedelta(seconds=15));q=json.loads(Path('outputs/vector-scale/design.json').read_text())['queries'][0];stmt=f'SELECT META(d).id AS id FROM {ks} d USE INDEX (scale_exact_cover USING GSI) WHERE d.country IS NOT MISSING ORDER BY VECTOR_DISTANCE(d.embedding,$q,"COSINE") LIMIT 10';params={'q':q}
plan=list(c.query('EXPLAIN '+stmt,QueryOptions(named_parameters=params)).rows());Path('outputs/vector-scale/covering-baseline-plan.json').write_text(json.dumps(plan,indent=2));t=time.perf_counter()
try:
 result=c.query(stmt,QueryOptions(named_parameters=params,metrics=True,timeout=timedelta(seconds=60)));rows=list(result.rows());r={'status':'passed','rows':rows,'client_ms':(time.perf_counter()-t)*1000,'server_ms':result.metadata().metrics().execution_time().total_seconds()*1000}
except Exception as e:r={'status':'failed','error':type(e).__name__,'client_ms':(time.perf_counter()-t)*1000}
Path('outputs/vector-scale/covering-baseline-probe.json').write_text(json.dumps(r,indent=2));print(r,flush=True);c.close()
